<?php

namespace App\Http\Requests\User\Password;

use Illuminate\Foundation\Http\FormRequest;

class PasswordUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $passwordCheckArray = [
            'password' => 'required|string|max:100',
            'confirm_password' => 'required|same:password|string|min:4|max:100',
            'token' => 'required|string|exists:users,remember_token'
        ];
        return $passwordCheckArray;
    }
}
