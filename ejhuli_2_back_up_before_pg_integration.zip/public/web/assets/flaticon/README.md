# WebFont Kit for most elegent free flaticons packs - creative ecommerce interface techology  
WebFont Kit for Angular2/Angular-cli project created using most elegent free flaticons packs - creative ecommerce interface techology  
This is a WebFont Kit package for most elegent flat icons

Install webfont kit in your local node modules using following command

```
npm install flat-icons
```

Include creative.css, ecommerce.css, interface.css or technology.css in your .angular-cli.json

```
"../node_modules/flat-icons/ecommerce.css",
"../node_modules/flat-icons/interface.css",
"../node_modules/flat-icons/technology.css",
"../node_modules/flat-icons/creative.css"
```
