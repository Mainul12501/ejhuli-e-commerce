<?php
return [
  'company_address' => "The Virtual BD <br/>
                        Home 234, Phase-2,<br/>
                        Road-10, Sonadanga Residential<br/>
                        Khulna-9100, Bangladesh",

    'contact_for_query' => config('app.name'). "<br/>
                        for any type of query please contact us <br/>
                        at email : contact@ejhuli.com <br/> contact: ". config('constants.footer_mobile'),

    'company_address_2' => config('app.name')."<br/>
                        Home 234, Phase-2,<br/>
                        Road-10, Sonadanga Residential<br/>
                        Khulna-9100, Bangladesh",
];
