
<div class="modal-busy-admin" id="loader" style="display: none">
   <div class="center-busy">
        {{--<img alt="" src="{{asset('assets/images/loaders/ajax-loading.gif')}}" />--}}
       <div class="spinner-dark"></div>
   </div>
</div>

