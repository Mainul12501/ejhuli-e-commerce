<div class="modal-busy" id="loader" style="display: none">
    <div class="center-busy">
        {{--<div class="lds-ellipsis" id="processIcons">
            <span></span>
            <span></span>
            <span></span>
        </div>--}}
        {{--<div class="text-center">
            <div class="spinner-border" role="status" style="color:#FF324D">
                <span class="sr-only">Loading...</span>
            </div>
        </div>--}}
        <div class="spinner-red"></div>
    </div>
</div>
