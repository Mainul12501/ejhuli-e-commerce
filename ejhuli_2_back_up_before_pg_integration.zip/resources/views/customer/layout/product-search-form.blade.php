<div class="product_search_form rounded_input">
    <form id="searchProductForm">
        <div class="input-group">
            <input  type="text" id="search_query" class="form-control" style="width: 100%" required>
            <button type="button" class="search_btn3"><i class="fa fa-search"></i></button>
        </div>
    </form>
</div>
