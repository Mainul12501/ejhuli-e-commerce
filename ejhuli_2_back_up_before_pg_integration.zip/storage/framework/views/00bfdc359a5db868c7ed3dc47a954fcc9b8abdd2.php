
<style>
    .scrollable-menu {
        height: auto;
        max-height: 200px;
        overflow-x: hidden;
    }
     #customerMenu  a:hover {
         color: #FF324D;
     }
</style>
<div class="col-lg-9 col-md-8 col-sm-6 col-9">
    <nav class="navbar navbar-expand-lg">
        <button class="navbar-toggler side_navbar_toggler" type="button" data-toggle="collapse" data-target="#navbarSidetoggle" aria-expanded="false">
            <span class="ion-android-menu"></span>
        </button>
        <div class="pr_search_icon">
            <a href="javascript:void(0);" class="nav-link pr_search_trigger"><i class="linearicons-magnifier"></i></a>
        </div>
        <div class="collapse navbar-collapse mobile_side_menu" id="navbarSidetoggle">
            <ul class="navbar-nav">
                <li><a class="nav-link nav_item" href="<?php echo e(url('/')); ?>">Home</a></li>
                <?php if($navigationMenus): ?>
                    <?php $__currentLoopData = $navigationMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($categories['sub_categories']): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><?php echo e($categories['category']); ?></a>
                            <div class="dropdown-menu dropdown-reverse">
                                <?php $__currentLoopData = $categories['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul>
                                    <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('viewProductByCatSubCat',[$categories['category_slug'],$subcategory['slug']])); ?>"><?php echo e($subcategory['subcategory']); ?></a></li>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                        <?php else: ?>
                            <li><a class="nav-link nav_item" href="<?php echo e(route('viewProductByCatSubCat',[$categories['category_slug'],''])); ?>"><?php echo e($categories['category']); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>

        <ul class="navbar-nav attr-nav align-items-center">
            <?php if(Auth::check()): ?>
                <li class="nav-item dropdown ml-2">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                        <i class="linearicons-user"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu dropdown-menu-left" id="customerMenu">
                        <a  href="<?php echo e(route('viewCustomerDashboard')); ?>" class="dropdown-item">My Account</a>
                        <a  href="<?php echo e(route('viewCustomerProfile')); ?>" class="dropdown-item d-none mobile-menu">Profile</a>
                        
                        <a  href="<?php echo e(route('viewNotifications')); ?>" class="dropdown-item d-none mobile-menu">Notifications</a>
                        <a  href="<?php echo e(route('viewPasswordSetting')); ?>" class="dropdown-item d-none mobile-menu">Password Setting</a>
                        <a  href="<?php echo e(route('viewCustomerAddresses')); ?>" class="dropdown-item d-none mobile-menu">Addresses</a>
                        <a  href="<?php echo e(route('viewCustomerOrders')); ?>" class="dropdown-item d-none mobile-menu">Orders</a>
                        <a  href="<?php echo e(route('viewReviews')); ?>" class="dropdown-item d-none mobile-menu">My Reviews</a>
                        <a  href="<?php echo e(route('viewNewsLetterSetting')); ?>" class="dropdown-item d-none mobile-menu">My Newsletter</a>
                        <a  href="<?php echo e(route('customerLogout')); ?>" class="dropdown-item">Logout</a>
                    </div>
                </li>
              

                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="true">
                        <i class="ti-bell"></i><span class="wishlist_count notifications-count">0</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" id="notification-container" style="left: inherit; right: -27px;">
                        <span class="dropdown-item dropdown-header nft-count"><span class="notifications-count">0</span> Notifications</span>
                        <div class="notification-dropdown">

                        </div>
                    </div>
                </li>
            <?php else: ?>
                <li><a href="<?php echo e(route('viewLogin')); ?>" class="nav-link text-capitalize" style="background-color: #FF334D;" id="colorWhiteOnHover">
                        sign in/sign up
                    </a></li>
                <style>
                    #colorWhiteOnHover:hover {
                        color: white!important;
                    }
                </style>

            <?php endif; ?>

            <li class="dropdown cart_dropdown">
              <a class="nav-link cart_trigger" href="#" data-toggle="dropdown"><i class="linearicons-bag2"></i><span class="cart_count">0</span><span class="amount"><span class="currency_symbol">৳</span><span class="cart_total_price">0</span></span></a>
                <?php echo $__env->make('customer.layout.cart-dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </li>
        </ul>
    </nav>
</div>
<?php /**PATH E:\WEB SECTION\WEB DEVELOPMENT SECTION\Xampp\htdocs\ejhuli\resources\views/customer/layout/main-menu.blade.php ENDPATH**/ ?>