<div class="col-lg-3 col-md-4 col-sm-6 col-3">
    <div class="categories_wrap">
        <button type="button" data-toggle="collapse" data-target="#navCatContent" aria-expanded="false" class="categories_btn">
            <i class="linearicons-menu"></i><span>All Categories</span>
        </button>
        <div id="navCatContent" class="<?php echo e(Request::segment(1) == ""?"nav_cat":""); ?> navbar collapse">
            <ul>
                <?php if($menuCategories): ?>
                    <?php $__currentLoopData = $menuCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($categories['sub_categories']): ?>
                        <li class="dropdown dropdown-mega-menu">
                            <a class="dropdown-item nav-link dropdown-toggler" href="<?php echo e(route('viewProductByCatSubCat',[$categories['category_slug'],''])); ?>" data-toggle="dropdown"><i class="<?php echo e($categories['icon_class']?$categories['icon_class']:'linearicons-film-play'); ?>"></i> <span><?php echo e($categories['category']); ?></span></a>
                            <div class="dropdown-menu">
                                <ul class="mega-menu d-lg-flex">
                                    <li class="mega-menu-col col-lg-7">
                                        <ul class="d-lg-flex">
                                            <?php $__currentLoopData = $categories['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mega-menu-col col-lg-6">
                                                <ul>
                                                    <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('viewProductByCatSubCat',[$categories['category_slug'],$subcategory['slug']])); ?>"><?php echo e($subcategory['subcategory']); ?></a></li>
                                                </ul>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <?php else: ?>
                            <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('viewProductByCatSubCat',[$categories['category_slug'],''])); ?>"><i class="<?php echo e($categories['icon_class']?$categories['icon_class']:'linearicons-film-play'); ?>"></i>  <span><?php echo e($categories['category']); ?></span></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/customer/layout/category-sidebar.blade.php ENDPATH**/ ?>