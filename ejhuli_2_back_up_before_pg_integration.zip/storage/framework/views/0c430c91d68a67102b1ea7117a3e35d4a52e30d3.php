<div class="modal-busy" id="loader" style="display: none">
    <div class="center-busy">
        
        
        <div class="spinner-red"></div>
    </div>
</div>
<?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/customer/layout/modal-busy.blade.php ENDPATH**/ ?>