<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('page-content'); ?>
<div class="row tile_count">
   
    <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-users"></i> Total Users</span>
        <div class="count"><?php echo e($totalCustomers); ?></div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-clock-o"></i> Total Categories</span>
        <div class="count"><?php echo e($totalCategories); ?></div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-pagelines"></i> Total Products</span>
        <div class="count green"><?php echo e($totalProducts); ?></div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-first-order"></i> Total Orders</span>
        <div class="count"><?php echo e($totalOrders); ?></div>
    </div>
</div>
<div class="row tile_count">
    <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-envelope-o"></i> Total Newsletters</span>
        <div class="count"><?php echo e($totalNewsletters); ?></div>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-dollar"></i> Total Collections</span>
        <div class="count">৳ <?php echo e($totalCollection); ?></div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>