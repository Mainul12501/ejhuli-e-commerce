
<div class="modal-busy-admin" id="loader" style="display: none">
   <div class="center-busy">
        
       <div class="spinner-dark"></div>
   </div>
</div>

<?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/admin/layout/busy.blade.php ENDPATH**/ ?>