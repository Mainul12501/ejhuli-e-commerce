<?php $__env->startSection('title','Create Password'); ?>
<?php $__env->startSection('page-content'); ?>
<div class="login_register_wrap section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-md-10">
                <div class="login_wrap">
                    <div class="padding_eight_all bg-white">
                        <div class="heading_s1"><h3>Create Password</h3></div>
                        <form id="createNewPasswordForm">
                            <div class="form-group">
                                <input type="password" name="password" id="password"  class="form-control"  placeholder="Password">
                            </div>
                            <div class="form-group">
                                <input type="password" name="confirm_password" id="confirm_password" class="form-control"  placeholder="Confirm Password">
                            </div>
                            <div class="form-group">
                                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                <button type="submit" class="btn btn-fill-out btn-block" >Change Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customer-js'); ?>
<script src="<?php echo e(asset('assets/js/customer/login/customer-password-reset.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.master-page-support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/customer/login/create-new-password.blade.php ENDPATH**/ ?>