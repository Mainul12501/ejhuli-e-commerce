<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo $__env->make('emails.css.mailer-css-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div style="margin-top: 20px;border: 1px solid #ddddd6;">
    <center>
        <img src="<?php echo e(asset('assets/images/admin_website_logo.png')); ?>" style="margin-top: 20px;"/>
    </center>
    <div style="padding: 20px; ">
        <div class="order-success">
            <center>
                <?php if($order->status == 1): ?>
                     <img src="https://i.imgur.com/bfoeLs3.png">
                <?php elseif($order->status == 2): ?>
                    <img src="https://i.imgur.com/tBi3ZXB.png">
                <?php elseif($order->status == 3): ?>
                    <img src="https://i.imgur.com/xMiA6qm.png">
                <?php elseif($order->status == 4): ?>
                    <img src="<?php echo e(asset('assets/images/icons/error-icon.PNG')); ?>" width="80" height="80"/>
                <?php endif; ?>
            </center>
        </div>
        <h3 class="card-title" style="text-align: center">Thank you for your order <strong>#<?php echo e($order->order_no); ?></strong> has been
            <?php if($order->status == 1): ?>
                placed
            <?php elseif($order->status == 2): ?>
                confirmed
            <?php elseif($order->status == 3): ?>
                delivered
            <?php elseif($order->status == 4): ?>
                Canceled
            <?php endif; ?>
        </h3>
        <?php if($order->status == 4): ?>
            <br/>
            <center>
                Please send your queries to <?php echo e(config('constants.footer_email')); ?>

            </center>
        <?php endif; ?>
        <p class="card-text">
            Hello <?php echo e($order->first_name); ?>, <br/>
            Thanks for letting us take care of your needs. <br/>
            We’re delighted to let you know that your order has been successfully placed by our trained delivery executive.

            <?php if($order->status == 3): ?> <br/><br/>
            We request you to please review your order, it will take less than 2 minutes.
             <a href="<?php echo e(route('orderDetail',['orderId' => $order->order_id])); ?>">Click here</a>
            <?php endif; ?>
        </p>
        <?php if($order->status == 2): ?>
        <h5 class="card-title">Estimated Delivery date : <?php echo e(date('d M Y', strtotime("+5 days"))); ?></h5>
        <?php endif; ?>
        <div class="my-orders">
            <div class="card-divider"></div>
            <div class="card-table">
                <div class="table-responsive-sm">
                    <table>
                        <thead>
                        <tr>
                            <th>Product</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody class="card-table__body card-table__body--merge-rows">
                        <?php if($orderProducts): ?>
                            <?php $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->product_name); ?> × <?php echo e($product->quantity); ?></td>
                                    <td>৳<?php echo e(number_format($product->price * $product->quantity)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                        <tbody class="card-table__body card-table__body--merge-rows">
                        <tr>
                            <th>Subtotal</th>
                            <td colspan="4">৳ <?php echo e($productSubTotal); ?> </td>
                        </tr>
                        <tr>
                            <th>Shipping Charges</th>
                            <td colspan="4"><?php if($deliveryChargeAmount): ?> ৳ <?php echo e(number_format($deliveryChargeAmount)); ?> <?php else: ?> Free <?php endif; ?></td>
                        </tr>
                        <tr>
                            <th>Payment Method</th>
                            <td colspan="4"><?php echo e($order->payment_method); ?></td>
                        </tr>
                        <?php if($discounts): ?>
                            <tr>
                                <th>Coupon Code</th>
                                <td colspan="4"><?php echo e(implode(',',$discounts)); ?> with total <?php echo e($totalDiscountPer); ?> % discount</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Total</th>
                            <td colspan="4">৳<?php echo e(number_format($totalPaymentAmount)); ?></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        <div class="card-divider"></div>
        <div style="margin-top:20px;">
            <center>
                <a href="<?php echo e(route('viewTrackOrder')); ?>" style="color: #FF324D;">Track Your Order</a>
            </center>
        </div>
        <div class="card-body">
            <h5 class="card-title">Delivery Address</h5>
            <p class="card-text"><?php echo e($order->full_name); ?><br/>
                <?php echo e($order->email); ?><br/>
                <?php echo e($order->contact); ?>,<br/>
                <?php echo e($order->street_address); ?><br/>
                <?php echo e($order->state); ?> - <?php echo e($order->country_name); ?><br />
                <?php echo e($order->town_city); ?> - <?php echo e($order->postal_code); ?>

            </p>
        </div>
        <div class="card-divider" style="margin-top:20px;"></div><br/>
        <div class="card-body">
            <h6 class="card-subtitle mb-2 text-muted">Thanks & Regards<br/>
               <?php echo app('translator')->get('common.company_address_2'); ?>
            </h6>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH E:\WEB SECTION\WEB DEVELOPMENT SECTION\Xampp\htdocs\ejhuli\resources\views/emails/customer/order-processed.blade.php ENDPATH**/ ?>