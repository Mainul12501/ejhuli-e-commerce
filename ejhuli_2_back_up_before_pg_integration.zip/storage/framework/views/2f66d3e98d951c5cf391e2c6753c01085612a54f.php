<div class="modal-busy" id="loader" style="display: none">
    <div class="center-busy">
        
        
        <div class="spinner-red"></div>
    </div>
</div>
<?php /**PATH E:\WEB SECTION\WEB DEVELOPMENT SECTION\Xampp\htdocs\ejhuli\resources\views/customer/layout/modal-busy.blade.php ENDPATH**/ ?>