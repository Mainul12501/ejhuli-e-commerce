<?php $__env->startSection('title','Order Detail - '.$order->order_no); ?>
<?php $__env->startSection('page-content'); ?>
<div class="">
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Order Detail</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <section class="content invoice">
                        <div class="row">
                            <div class="col-xs-12 invoice-header">
                                <h1>
                                    <i class="fa fa-first-order"></i> <span style="font-size: 30px;">ORDER #<?php echo e($order->order_no); ?></span>
                                    <small class="pull-right">Date: <?php echo e($order->placed_date); ?></small>
                                </h1>
                            </div>
                        </div>
                        <div class="row invoice-info">
                            <div class="col-sm-6 invoice-col">
                                From
                                <address>
                                    <?php echo app('translator')->get('common.company_address'); ?>
                                </address>
                            </div>
                            <div class="col-sm-6 invoice-col">
                                To
                                <address>
                                    <strong><?php echo e($order->full_name); ?></strong>
                                    <br> <?php echo e($order->street_address); ?>

                                    <br><?php echo e($order->state); ?>, <?php echo e($order->country_name); ?>

                                    <br> <?php echo e($order->town_city); ?> - <?php echo e($order->postal_code); ?>

                                    <br>Phone: <?php echo e($order->contact); ?>

                                    <br>Email: <?php echo e($order->email); ?>

                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 table">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Product</th>
                                        <th>SKU</th>
                                        <th>Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if($orderDetail): ?>
                                        <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($product->product_name); ?> × <?php echo e($product->quantity); ?></td>
                                                <td><?php echo e($product->sku); ?></td>
                                                <td>৳ <?php echo e($product->price * $product->quantity); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 table">
                                <div class="table-responsive">
                                    <table class="table">
                                        <tbody>
                                        <tr>
                                            <th>Subtotal</th>
                                            <td colspan="4">৳ <?php echo e($productSubTotal); ?> </td>
                                        </tr>
                                        <?php if($discounts): ?>
                                            <tr>
                                                <th>Discount</th>
                                                <td colspan="4">Coupon <?php echo e(implode(',',$discounts)); ?> with total <?php echo e($totalDiscountPer); ?>% discount amount ৳ <?php echo e($totalDiscountAmount); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <th>Shipping Charges</th>
                                            <td colspan="4"><?php if($deliveryChargeAmount): ?> ৳ <?php echo e(number_format($deliveryChargeAmount)); ?> <?php else: ?> Free <?php endif; ?></td>
                                        </tr>
                                        <tr>
                                            <th>Payment Method</th>
                                            <td colspan="4"><?php echo e($order->payment_method); ?></td>
                                        </tr>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Total</th>
                                            <td colspan="4">৳<?php echo e(number_format($totalPaymentAmount)); ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row no-print">
                            <div class="col-xs-12">
                                <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/admin/orders/order-detail.blade.php ENDPATH**/ ?>