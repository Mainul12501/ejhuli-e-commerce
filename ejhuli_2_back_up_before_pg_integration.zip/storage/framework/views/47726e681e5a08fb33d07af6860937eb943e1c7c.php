<div class="top_nav">
    <div class="nav_menu">
        <nav>
            <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li class="">
                    <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <?php if($adminUser->profile_pic): ?>
                            <img src="<?php echo e(asset('storage/uploads/profile/admin/'.$adminUser->profile_pic)); ?>" id="admin-profile-img" alt="<?php echo e($adminUser->profile_pic); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/avtar/avtar.png')); ?>" alt="...">
                        <?php endif; ?>
                       <span id="admin-name"> <?php echo e($adminUser->name); ?></span> <span class=" fa fa-angle-down"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-usermenu pull-right">
                        <li><a href="<?php echo e(route('viewAdminProfile')); ?>"> Profile</a></li>
                        <li><a href="<?php echo e(route('adminLogout')); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                    </ul>
                </li>
                <li role="presentation" class="dropdown" style="display:none;">
                    <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                        <i class="fa fa-envelope-o"></i>
                        <span class="badge bg-green">6</span>
                    </a>
                    <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                        <li>
                            <div class="text-center">
                                <a href="messages">
                                    <strong>See All Alerts</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH E:\WEB SECTION\WEB DEVELOPMENT SECTION\Xampp\htdocs\ejhuli\resources\views/admin/layout/navigation.blade.php ENDPATH**/ ?>