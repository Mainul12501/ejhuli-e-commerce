
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="theme-color" content="#FF324D">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="Anil z" name="author">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($seoData->meta_description); ?>">
    <meta name="keywords" content="<?php echo e($seoData->meta_keywords); ?>">
    <!-- SITE TITLE -->
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon Icon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/website_favicon.png')); ?>">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/animate.css')); ?>">
    <!-- Latest Bootstrap min CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/ionicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/linearicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/simple-line-icons.css')); ?>">
    <!--- owl carousel CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/owlcarousel/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/owlcarousel/css/owl.theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/owlcarousel/css/owl.theme.default.min.css')); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/magnific-popup.css')); ?>">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/slick-theme.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/custom-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/customer/home-page-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/assets/css/responsive.css')); ?>">
    <link href="<?php echo e(asset('assets/css/busy.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/customer/customer-panel-stype.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/assets/toaster/toastr.min.css')); ?>" rel="stylesheet"/>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.10.12/dist/sweetalert2.all.min.js"></script>
    <link href="<?php echo e(asset('web/assets/autocomplete/jquery.autocomplete.css')); ?>" rel="stylesheet"/>
    <script>
        let BASE_URL = <?php echo json_encode(url('/')); ?>+"/";
        console.log(BASE_URL);
    </script>

</head>

<body>

<!-- LOADER -->

<!-- END LOADER -->

<!-- Home Popup Section -->

<!-- End Screen Load Popup Section -->

<!-- START HEADER -->
<header class="header_wrap">
    <div class="top-header light_skin bg_dark d-none d-md-block">
        <div class="custom-container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-8">
                    <div class="header_topbar_info">
                        <div class="header_offer">
                            <span><?php echo e($offer_text); ?></span>
                        </div>
                        <div class="download_wrap">
                            <span class="mr-3">Download App</span>
                            <ul class="icon_list text-center text-lg-left">
                                <li><a href="#"><i class="fab fa-android"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="middle-header dark_skin">
        <div class="custom-container">
            <div class="nav_block">
                <a class="navbar-brand" href="<?php echo e(route('viewHome')); ?>">
                    <?php if(!$websiteLogo): ?>
                        <img class="logo_dark" src="<?php echo e(asset('assets/images/logo_default_dark.png')); ?>" alt="logo" />
                    <?php else: ?>
                        <img class="logo_dark" src="<?php echo e(asset('storage/uploads/media/'. $websiteLogo)); ?>" alt="logo" />
                    <?php endif; ?>
                </a>
                <?php echo $__env->make('customer.layout.product-search-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="contact_phone contact_support">
                    <i class="linearicons-phone-wave" style="font-size: 18px;"></i>
                    <span>+880 1932 974 266</span>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom_header dark_skin main_menu_uppercase border-top border-bottom">
        <div class="custom-container">
            <div class="row">
                <?php echo $__env->make('customer.layout.category-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('customer.layout.main-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</header>
<!-- END HEADER -->


<!-- END MAIN CONTENT -->
<div class="main_content">
    <?php echo $__env->yieldContent('page-content'); ?>
</div>

<!-- END MAIN CONTENT -->

<?php echo $__env->make('customer.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('customer.layout.modal-busy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a>

<!-- Latest jQuery -->
<script src="<?php echo e(asset('web/assets/js/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/assets/validate-js/jquery.validate.min.js')); ?>"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('assets/js/common.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/customer/newsletter/newsletter.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/customer/cart/create-update-cart.js')); ?>"></script>
<?php echo $__env->yieldContent('customer-js'); ?>
<script src="<?php echo e(asset('web/assets/toaster/toastr.min.js')); ?>"></script>
<?php if(Auth::check()): ?>
    <script src="https://js.pusher.com/4.2/pusher.min.js"></script>
    <script src="<?php echo e(asset('assets/js/notifications.js')); ?>"></script>
<?php endif; ?>
<!-- popper min js -->
<script src="<?php echo e(asset('web/assets/js/popper.min.js')); ?>"></script>
<!-- Latest compiled and minified Bootstrap -->
<script src="<?php echo e(asset('web/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- owl-carousel min js  -->
<script src="<?php echo e(asset('web/assets/owlcarousel/js/owl.carousel.min.js')); ?>"></script>
<!-- magnific-popup min js  -->
<script src="<?php echo e(asset('web/assets/js/magnific-popup.min.js')); ?>"></script>
<!-- waypoints min js  -->
<script src="<?php echo e(asset('web/assets/js/waypoints.min.js')); ?>"></script>
<!-- parallax js  -->
<script src="<?php echo e(asset('web/assets/js/parallax.js')); ?>"></script>
<!-- countdown js  -->
<script src="<?php echo e(asset('web/assets/js/jquery.countdown.min.js')); ?>"></script>
<!-- fit video  -->
<script src="<?php echo e(asset('web/assets/js/Hoverparallax.min.js')); ?>"></script>
<!-- jquery.countTo js  -->
<script src="<?php echo e(asset('web/assets/js/jquery.countTo.js')); ?>"></script>
<!-- imagesloaded js -->
<script src="<?php echo e(asset('web/assets/js/imagesloaded.pkgd.min.js')); ?>'"></script>
<!-- isotope min js -->
<script src="<?php echo e(asset('web/assets/js/isotope.min.js')); ?>"></script>
<!-- jquery.appear js  -->
<script src="<?php echo e(asset('web/assets/js/jquery.appear.js')); ?>"></script>
<!-- jquery.parallax-scroll js -->
<script src="<?php echo e(asset('web/assets/js/jquery.parallax-scroll.js')); ?>"></script>
<!-- jquery.dd.min js -->
<script src="<?php echo e(asset('web/assets/js/jquery.dd.min.js')); ?>"></script>
<!-- slick js -->
<script src="<?php echo e(asset('web/assets/js/slick.min.js')); ?>"></script>
<!-- elevatezoom js -->
<script src="<?php echo e(asset('web/assets/js/jquery.elevatezoom.js')); ?>"></script>
<!-- scripts js -->
<script src="<?php echo e(asset('web/assets/js/scripts.js')); ?>"></script>

</body>
</html>
<?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/customer/layout/master-page-support.blade.php ENDPATH**/ ?>