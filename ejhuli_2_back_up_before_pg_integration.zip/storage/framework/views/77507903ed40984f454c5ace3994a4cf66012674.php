<?php $__env->startSection('title','Analytics'); ?>
<?php $__env->startSection('page-content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 hide-in-mobile">
            <?php echo $__env->make('customer.layout.customer-menus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-9" style="padding: 5px;">
            <div class="section customer-home-section pt-1">
                <div class="wallet-card">
                    <h3>Analytics</h3>
                    <div class="row">
                        <div class="col">
                            <div class="balance">
                                <div class="left">
                                    <span class="title">Wallet Balance</span>
                                    <h1 class="total" id="currentBalance">৳ <?php echo e($wallet_balance); ?></h1>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="balance">
                                <div class="left">
                                    <span class="title">Total Spent</span>
                                    <h1 class="total" id="currentBalance">৳ <?php echo e($total_spent); ?></h1>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="balance">
                                <div class="left">
                                    <span class="title">Order Placed</span>
                                    <h1 class="total" id="currentBalance"><?php echo e($total_orders); ?></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.master-page-support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/customer/analytics/analytics.blade.php ENDPATH**/ ?>