<?php $__env->startSection('title','Sign In'); ?>
<?php $__env->startSection('page-content'); ?>
    <!-- START LOGIN SECTION -->
    <div class="login_register_wrap section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-md-10">
                    <div class="login_wrap">
                        <div class="padding_eight_all bg-white">
                            <div class="heading_s1">
                                <h3>Login</h3>
                            </div>
                           <?php echo $__env->make('customer.layout.login-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END LOGIN SECTION -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customer-js'); ?>
<script src="<?php echo e(asset('assets/js/customer/login/customer-login.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.master-page-support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WEB SECTION\WEB DEVELOPMENT SECTION\Xampp\htdocs\ejhuli\resources\views/customer/login/login.blade.php ENDPATH**/ ?>