
<?php if($paginator->lastPage() > 1): ?>
    <ul class="pagination mt-3 justify-content-center pagination_style1">
        <li class="page-item <?php echo e(($paginator->currentPage() == 1) ? ' disabled' : ''); ?>">
            <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>"><i class="linearicons-arrow-left"></i></a>
        </li>
        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
            <li class="page-item <?php echo e(($paginator->currentPage() == $i) ? ' active' : ''); ?>">
                <a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            </li>
        <?php endfor; ?>
        <li class="page-item <?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? ' disabled' : ''); ?>">
            <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>" ><i class="linearicons-arrow-right"></i></a>
        </li>
    </ul>
<?php endif; ?>
<?php /**PATH E:\WEB SECTION\WEB DEVELOPMENT SECTION\Xampp\htdocs\ejhuli\resources\views/customer/layout/pagination.blade.php ENDPATH**/ ?>