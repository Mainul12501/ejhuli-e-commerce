<?php $__env->startSection('title','Track Order'); ?>
<?php $__env->startSection('page-content'); ?>
<div class="section">
    <div class="container">
        <div class="field_form">
            <p class="text-center leads theme-color"><strong>Track Your Order From Anywhere</strong></p>
            <form id="track-order-form">
               <div class="row justify-content-center">
                   <div class="col">
                       <div class="input-group input-group">
                           <input type="text" name="order_no" id="order_no" placeholder="Order No." class="form-control" required="required">
                           <span class="input-group-btn"><button type="submit" id="trackOrderBtn" class="btn btn-fill-out"> <i class="fa fa-search"></i> Track</button></span>
                       </div>
                       <div id="order_noError" class="error"></div>
                   </div>
               </div>
            </form>
        </div>
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div id="tracking-data">

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customer-js'); ?>
<script src="<?php echo e(asset('assets/js/customer/order-tracking/order-tracking.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout.master-page-support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swarnalimollick/ejhuli.com/resources/views/customer/order-tracking/order-tracking.blade.php ENDPATH**/ ?>